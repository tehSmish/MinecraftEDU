package mod.elite_puddle.minecraftedu.init;

import mod.elite_puddle.minecraftedu.util.Reference;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraftforge.registries.ObjectHolder;

//creates a reference to our items for the creative menu
@ObjectHolder(Reference.MOD_ID)
public class ModItems {
	public static final Item EXAMPLE_ITEM = null;
	public static final Block NOT_BLOCK = null;
	
}
