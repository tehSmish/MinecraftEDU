package mod.elite_puddle.minecraftedu;

import mod.elite_puddle.minecraftedu.util.Reference;
import net.minecraftforge.fml.common.Mod;

@Mod(Reference.MOD_ID)
public class Main {
	
	public Main() {
		Reference.LOGGER.debug("Hello World");
	}
	
}
