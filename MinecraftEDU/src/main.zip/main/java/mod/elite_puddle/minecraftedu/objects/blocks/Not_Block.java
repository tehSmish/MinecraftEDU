package mod.elite_puddle.minecraftedu.objects.blocks;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.RedstoneTorchBlock;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer.Builder;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;


public class Not_Block extends Block {
	public static final BooleanProperty LIT = RedstoneTorchBlock.LIT;
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	
	public Not_Block(Properties properties) {
		super(properties);
		this.setDefaultState(this.stateContainer.getBaseState()
		.with(FACING, Direction.NORTH).with(LIT, Boolean.valueOf(false)));
	}
	
	//sets the block to always be placed facing the player
	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return this.getDefaultState()
		.with(FACING, context.getPlacementHorizontalFacing().getOpposite())
		.with(LIT, Boolean.valueOf(context.getWorld().isBlockPowered(context.getPos())));
	}
	
	@SuppressWarnings("deprecation")
	public int getLightValue(BlockState state) {
	    return state.get(LIT) ? super.getLightValue(state) : 0;
	}

	@SuppressWarnings("deprecation")
	public void onBlockAdded(BlockState state, World worldIn, BlockPos pos, BlockState oldState, boolean isMoving) {
		super.onBlockAdded(state, worldIn, pos, oldState, isMoving);
	}

	public void neighborChanged(BlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving) {
		if (!worldIn.isRemote) {
			boolean flag = state.get(LIT);
		if (flag != worldIn.isBlockPowered(pos)) {
			if (flag) {
				worldIn.getPendingBlockTicks().scheduleTick(pos, this, 4);
			} else {
				worldIn.setBlockState(pos, state.cycle(LIT), 2);
			}
		}
		
		}
	}

	public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
		if (p_225534_1_.get(LIT) && !p_225534_2_.isBlockPowered(p_225534_3_)) {
			p_225534_2_.setBlockState(p_225534_3_, p_225534_1_.cycle(LIT), 2);
		}
		
	}
	
	@Override
	protected void fillStateContainer(Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}
		
}